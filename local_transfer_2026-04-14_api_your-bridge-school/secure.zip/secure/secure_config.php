<?php
return [
    'GOOGLE_APPLICATION_CREDENTIALS' => '/home/vscgzfvf/private/firebase-service-account.json',
    'FIREBASE_DB_URL' => 'https://dreamenglishacademy-3efcd-default-rtdb.firebaseio.com',
    'YBS_STORAGE_DIR' => '/home/vscgzfvf/api.yourbridgeschool.com/apps/your-bridge-school/storage',
    'YBS_PUBLIC_BASE_URL' => 'https://api.yourbridgeschool.com/apps/your-bridge-school/storage',
];